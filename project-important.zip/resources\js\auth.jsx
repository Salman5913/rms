import { createContext, useContext, useEffect, useState } from "react";
import api from "./api";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(!!localStorage.getItem("rms_token"));

    useEffect(() => {
        if (localStorage.getItem("rms_token")) {
            api.get("/me").then((r) => setUser(r.data)).catch(() => {}).finally(() => setLoading(false));
        }
    }, []);

    const login = async (email, password) => {
        const r = await api.post("/login", { email, password });
        localStorage.setItem("rms_token", r.data.token);
        setUser(r.data.user);
    };

    const logout = async () => {
        try { await api.post("/logout"); } catch {}
        localStorage.removeItem("rms_token");
        setUser(null);
        location.href = "/login";
    };

    /** module visibility / action permission (administrator bypasses) */
    const can = (module, action = "view") => {
        if (!user) return false;
        if (user.role?.code === "administrator") return true;
        return !!user.permissions?.[module]?.[action];
    };

    return <AuthCtx.Provider value={{ user, loading, login, logout, can }}>{children}</AuthCtx.Provider>;
}

export const useAuth = () => useContext(AuthCtx);
