<?php

namespace App\Http\Controllers\Admin;

use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RoleController extends ApiCrudController
{
    protected string $model = Role::class;
    protected array $search = ['name', 'code'];
    protected array $with = ['permissions'];

    protected function rules(Request $request, $model = null): array
    {
        return [
            'name'   => 'required|string|max:255',
            'code'   => 'nullable|string|max:100',
            'status' => 'nullable|boolean',
            'permissions'          => 'nullable|array',
            'permissions.*.module' => 'string',
            'permissions.*.can_create' => 'boolean',
            'permissions.*.can_edit'   => 'boolean',
            'permissions.*.can_view'   => 'boolean',
        ];
    }

    protected function fields(array $data): array
    {
        return [
            'name' => $data['name'],
            'code' => $data['code'] ?? \Illuminate\Support\Str::slug($data['name']),
            'status' => $data['status'] ?? true,
        ];
    }

    protected function syncRelations($model, array $data): void
    {
        $model->permissions()->delete();
        foreach ($data['permissions'] ?? [] as $p) {
            if ($p['can_view'] ?? false) {
                $model->permissions()->create($p);
            }
        }
    }
}
