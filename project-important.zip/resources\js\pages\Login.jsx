import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth";
import { Btn, inputCls } from "../ui";

export default function Login() {
    const { login } = useAuth();
    const nav = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [busy, setBusy] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        setBusy(true); setError("");
        try {
            await login(email, password);
            nav("/");
        } catch {
            setError("Invalid email or password");
        } finally { setBusy(false); }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-[#1F2430] to-[#3a2b2c] flex items-center justify-center p-4">
            <form onSubmit={submit} className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-10">
                <div className="text-center mb-8">
                    <p className="text-4xl mb-2">🍽️</p>
                    <h1 className="text-2xl font-extrabold text-gray-800">Restaurant RMS</h1>
                    <p className="text-sm text-gray-400 mt-1">Sign in to manage your restaurant</p>
                </div>
                {error && <p className="text-sm text-red-600 bg-red-50 rounded-xl px-4 py-2.5 mb-4">{error}</p>}
                <div className="space-y-4">
                    <input type="email" required placeholder="Email address" value={email}
                        onChange={(e) => setEmail(e.target.value)} className={inputCls} />
                    <input type="password" required placeholder="Password" value={password}
                        onChange={(e) => setPassword(e.target.value)} className={inputCls} />
                </div>
                <Btn type="submit" disabled={busy}
                    className="w-full mt-6 bg-red-600 text-white py-3 justify-center hover:bg-red-700 disabled:opacity-50">
                    {busy ? "Signing in…" : "Sign In"}
                </Btn>
            </form>
        </div>
    );
}
