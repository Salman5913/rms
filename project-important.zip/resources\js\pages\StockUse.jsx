import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import { Btn, inputCls } from "../ui";

const emptyRow = () => ({ stock_item_id: "", value: "" });

/** Stock Use Voucher: dynamic rows, items excluded once picked, zero-stock hidden. */
export default function StockUse() {
    const [items, setItems] = useState([]);
    const [rows, setRows] = useState([emptyRow()]);
    const [error, setError] = useState("");
    const nav = useNavigate();

    useEffect(() => {
        api.get("/admin/stock-items", { params: { all: 1 } }).then((r) =>
            setItems(r.data.filter((i) => Number(i.value) > 0))
        );
    }, []);

    const chosen = rows.map((r) => r.stock_item_id).filter(Boolean);
    const availableFor = (row) =>
        items.filter((i) => !chosen.includes(String(i.id)) || String(i.id) === String(row.stock_item_id));

    const setRow = (i, patch) => setRows((rs) => rs.map((r, j) => (j === i ? { ...r, ...patch } : r)));

    const save = async () => {
        setError("");
        if (rows.some((r) => !r.stock_item_id || !r.value)) return setError("Fill all rows or remove empty ones");
        try {
            await api.post("/admin/stock-use-vouchers", {
                items: rows.map((r) => ({ stock_item_id: Number(r.stock_item_id), value: Number(r.value) })),
            });
            nav("/stock-items");
        } catch (err) {
            setError(err.response?.data?.message ?? "Failed to save voucher");
        }
    };

    return (
        <div className="max-w-2xl">
            <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-extrabold text-gray-800">Stock Use Voucher</h2>
                <Btn onClick={() => nav("/stock-items")} className="bg-white border">← Back</Btn>
            </div>

            <div className="bg-white rounded-2xl border shadow-sm p-6 space-y-3">
                {error && <p className="text-sm text-red-600 bg-red-50 rounded-xl px-4 py-2.5">{error}</p>}

                {rows.map((row, i) => {
                    const item = items.find((x) => String(x.id) === String(row.stock_item_id));
                    return (
                        <div key={i} className="flex items-start gap-2">
                            <select value={selected} onChange={(e) => setRow(i, { stock_item_id: e.target.value })}
                                className={inputCls + " flex-1"}>
                                <option value="selected">— select item —</option>
                                {availableFor(row).map((x) => (
                                    <option key={x.id} value={x.id}>{x.name} (available: {x.value} {x.unit})</option>
                                ))}
                            </select>
                            <input type="number" min="0" value={row.value}
                                placeholder={item ? `Enter amount in ${item.unit}` : "Value"}
                                onChange={(e) => setRow(i, { value: e.target.value })}
                                className={inputCls + " w-48"} />
                            <div className="flex gap-1 pt-1">
                                {rows.length > 1 && (
                                    <button onClick={() => setRows((rs) => rs.filter((_, j) => j !== i))}
                                        className="w-8 h-8 rounded-lg bg-red-50 hover:bg-red-100" title="Remove row">−</button>
                                )}
                                {i === rows.length - 1 && (
                                    <button onClick={() => setRows((rs) => [...rs, emptyRow()])}
                                        className="w-8 h-8 rounded-lg bg-green-50 hover:bg-green-100" title="Add row">＋</button>
                                )}
                            </div>
                        </div>
                    );
                })}

                <div className="pt-3">
                    <Btn onClick={save} className="bg-red-600 text-white hover:bg-red-700">💾 Save Voucher</Btn>
                </div>
            </div>
        </div>
    );
}
