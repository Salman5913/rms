import { useEffect, useRef, useState } from "react";

export const inputCls =
    "w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 bg-white";

export function Field({ label, required, children }) {
    return (
        <label className="block">
            <span className="text-sm font-medium text-gray-600">
                {label} {required && <span className="text-red-500">*</span>}
            </span>
            <div className="mt-1">{children}</div>
        </label>
    );
}

export function ImageUpload({ value, onChange }) {
    const [uploading, setUploading] = useState(false);
    const pick = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const fd = new FormData();
        fd.append("file", file);
        setUploading(true);
        try {
            const r = await api.post("/upload", fd);
            onChange(r.data.url);
        } finally { setUploading(false); }
    };
    return (
        <div>
            {value && <img src={value} alt="" className="h-28 rounded-xl object-cover mb-2 border" />}
            <input type="file" accept="image/*" onChange={pick} className="text-sm" />
            {uploading && <p className="text-xs text-gray-400 mt-1">Uploading…</p>}
        </div>
    );
}

import api from "./api";

export function MultiSelect({ endpoint, value = [], onChange, placeholder = "Select…" }) {
    const [open, setOpen] = useState(false);
    const [options, setOptions] = useState([]);
    const ref = useRef();

    useEffect(() => {
        api.get(endpoint).then((r) => setOptions(r.data));
    }, [endpoint]);

    useEffect(() => {
        const close = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
        document.addEventListener("mousedown", close);
        return () => document.removeEventListener("mousedown", close);
    }, []);

    const toggle = (id) =>
        onChange(value.includes(id) ? value.filter((v) => v !== id) : [...value, id]);

    const label = (id) => options.find((o) => o.id === id)?.name ?? id;

    return (
        <div className="relative" ref={ref}>
            <button type="button" onClick={() => setOpen(!open)}
                className={inputCls + " flex flex-wrap gap-1 text-left min-h-[42px]"}>
                {value.length === 0 && <span className="text-gray-400">{placeholder}</span>}
                {value.map((id) => (
                    <span key={id} className="bg-red-50 text-red-700 text-xs font-semibold px-2 py-1 rounded-full">
                        {label(id)}
                        <span className="ml-1 cursor-pointer" onClick={(e) => { e.stopPropagation(); toggle(id); }}>✕</span>
                    </span>
                ))}
                <span className="ml-auto text-gray-400">▾</span>
            </button>
            {open && (
                <div className="absolute z-30 mt-1 w-full bg-white border rounded-xl shadow-lg max-h-56 overflow-y-auto">
                    {options.map((o) => (
                        <label key={o.id} className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-50 cursor-pointer">
                            <input type="checkbox" checked={value.includes(o.id)} onChange={() => toggle(o.id)}
                                className="accent-red-600" />
                            {o.name}
                            {o.price !== undefined && o.price > 0 && <span className="text-gray-400 text-xs">(+{o.price})</span>}
                        </label>
                    ))}
                </div>
            )}
        </div>
    );
}

export function Spinner() {
    return <div className="flex justify-center py-20 text-gray-400">Loading…</div>;
}

export function Btn({ children, className = "", ...props }) {
    return (
        <button {...props}
            className={"inline-flex items-center gap-1.5 text-sm font-semibold px-4 py-2 rounded-xl transition " + className}>
            {children}
        </button>
    );
}
