import { Route, Routes } from "react-router-dom";
import { CrudPage, CrudForm } from "../Crud";

const MODULES = ["dashboard", "banners", "products", "options", "extras", "categories",
    "deals", "orders", "stock-items", "stock-use", "users", "roles"];

const columns = [
    { key: "name", label: "Role Name" },
    { key: "code", label: "Code" },
    { key: "status", label: "Status", render: (r) => (r.status ? "✅ Active" : "⛔ Disabled") },
];

/** permissions matrix editor */
function PermissionsMatrix({ value = [], onChange }) {
    const update = (module, action, checked) => {
        const rest = value.filter((p) => p.module !== module);
        const existing = value.find((p) => p.module === module) ?? { module, can_create: false, can_edit: false, can_view: false };
        onChange([...rest, { ...existing, [action]: checked }]);
    };
    const get = (m, a) => !!value.find((p) => p.module === m)?.[a];

    return (
        <div className="border rounded-xl overflow-hidden">
            <table className="w-full text-sm">
                <thead>
                    <tr className="bg-gray-50 text-gray-500 border-b">
                        <th className="text-left p-3 font-semibold">Module</th>
                        {["can_create", "can_edit", "can_view"].map((a) => (
                            <th key={a} className="p-3 font-semibold capitalize w-24">{a.replace("can_", "")}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {MODULES.map((m) => (
                        <tr key={m} className="border-b last:border-0">
                            <td className="p-3 capitalize font-medium">{m.replace("-", " ")}</td>
                            {["can_create", "can_edit", "can_view"].map((a) => (
                                <td key={a} className="p-3 text-center">
                                    <input type="checkbox" checked={get(m, a)} disabled={value === undefined}
                                        onChange={(e) => update(m, a, e.target.checked)} className="accent-red-600" />
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
            <p className="text-xs text-gray-400 p-3 bg-gray-50">Tip: checking any permission enables “view” access to that module’s menu.</p>
        </div>
    );
}

export default function Roles() {
    const fields = [
        { name: "name", label: "Role Name", required: true },
        { name: "code", label: "Role Code" },
        { name: "status", label: "Active", type: "checkbox", default: true },
        {
            name: "permissions", label: "Module Permissions", default: [],
            render: (p) => <PermissionsMatrix {...p} />,
        },
    ];
    return (
        <Routes>
            <Route index element={<CrudPage title="Roles" endpoint="admin/roles" columns={columns} />} />
            <Route path="create" element={<CrudForm title="Role" endpoint="admin/roles" fields={fields} backTo="/roles" />} />
            <Route path=":id" element={<CrudForm title="Role" endpoint="admin/roles" fields={fields} backTo="/roles" />} />
            <Route path=":id/edit" element={<CrudForm title="Role" endpoint="admin/roles" fields={fields} backTo="/roles" />} />
        </Routes>
    );
}
