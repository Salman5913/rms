<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $from = Carbon::parse($request->query('from', now()->toDateString()))->startOfDay();
        $to   = Carbon::parse($request->query('to', now()->toDateString()))->endOfDay();

        $orders = Order::whereBetween('created_at', [$from, $to])->get();
        $web    = $orders->where('type', 'website');
        $pick   = $orders->where('type', 'pickup');

        // daily series for line chart
        $days = $from->copy();
        $labels = $ordersCount = $revenue = [];
        while ($days <= $to) {
            $dayOrders = $orders->filter(fn ($o) => $o->created_at->isSameDay($days));
            $labels[] = $days->toDateString();
            $ordersCount[] = $dayOrders->count();
            $revenue[] = (float) $dayOrders->sum('total');
            $days->addDay();
        }

        return response()->json([
            'total_sales'      => (float) $orders->sum('total'),
            'total_orders'     => $orders->count(),
            'website_orders'   => $web->count(),
            'pickup_orders'    => $pick->count(),
            'website_sales'    => (float) $web->sum('total'),
            'pickup_sales'     => (float) $pick->sum('total'),
            'chart' => ['labels' => $labels, 'orders' => $ordersCount, 'revenue' => $revenue],
        ]);
    }
}
