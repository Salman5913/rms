import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import { Btn, Spinner, inputCls } from "../ui";
import { StatusSelect } from "./WebsiteOrders";

/* mini product card (~4x smaller than website card) */
function MiniCard({ item, onAdd }) {
    const hasRequired = (item.modifiers ?? []).some((g) => g.required);
    return (
        <div onClick={() => onAdd(item)}
            className={"bg-white rounded-xl border shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition " +
                (item._disabled ? "opacity-40 pointer-events-none" : "")}>
            <img src={item.image ?? "/placeholder-food.png"} alt={item.name} className="h-16 w-full object-cover bg-gray-100" />
            <div className="p-2">
                <p className="text-xs font-bold truncate">{item.name}</p>
                <p className="text-[11px] text-red-600 font-bold">Rs. {Number(item.price).toLocaleString()}</p>
                {hasRequired && <p className="text-[10px] text-gray-400">customization required</p>}
            </div>
        </div>
    );
}

/* compact modifier popup */
function MiniModal({ item, onClose, onConfirm }) {
    const [sel, setSel] = useState({});
    const groups = item.modifiers ?? [];
    const toggle = (g, oid) => setSel((s) => {
        const cur = s[g._key] ?? [];
        return { ...s, [g._key]: g.type === "single" ? [oid] : cur.includes(oid) ? cur.filter((x) => x !== oid) : [...cur, oid] };
    });
    const mods = groups.flatMap((g) => (sel[g._key] ?? []).map((oid) => ({
        groupId: g.id, groupName: g.name,
        option: g.options.find((o) => o.id === oid),
    })));
    const unit = item.price + mods.reduce((s, m) => s + Number(m.option.price), 0);
    const missing = groups.filter((g) => g.required && !(sel[g._key] ?? []).length).length;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40" onClick={onClose} />
            <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-sm p-5">
                <div className="flex justify-between items-start mb-3">
                    <h3 className="font-bold">{item.name}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
                </div>
                {groups.map((g) => (
                    <div key={g._key} className="mb-3">
                        <p className="text-xs font-bold text-gray-500 mb-1.5">
                            {g.name} {g.required && <span className="text-red-500">* select 1</span>}
                        </p>
                        <div className="space-y-1">
                            {g.options.map((o) => (
                                <label key={o.id} className="flex items-center gap-2 text-sm border rounded-lg px-3 py-1.5 cursor-pointer">
                                    <input type={g.type === "single" ? "radio" : "checkbox"} name={g._key}
                                        checked={(sel[g._key] ?? []).includes(o.id)} onChange={() => toggle(g, o.id)}
                                        className="accent-red-600" />
                                    {o.name}
                                    {Number(o.price) > 0 && <span className="ml-auto text-xs text-gray-400">+{o.price}</span>}
                                </label>
                            ))}
                        </div>
                    </div>
                ))}
                <Btn onClick={() => { if (missing === 0) onConfirm(mods, unit); }}
                    disabled={missing > 0}
                    className="w-full bg-red-600 text-white justify-center disabled:opacity-40">
                    Add — Rs. {unit.toLocaleString()}
                </Btn>
            </div>
        </div>
    );
}

/* ---------------- pickup orders listing ---------------- */
export default function PickupOrders() {
    const [data, setData] = useState(null);
    const [search, setSearch] = useState("");
    const nav = useNavigate();

    const load = (s = search) =>
        api.get("/admin/orders", { params: { type: "pickup", search: s } }).then((r) => setData(r.data));
    useEffect(() => { load(); }, []); // eslint-disable-line
    useEffect(() => { const t = setTimeout(() => load(search), 300); return () => clearTimeout(t); }, [search]); // eslint-disable-line

    if (!data) return <Spinner />;

    return (
        <div>
            <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
                <h2 className="text-xl font-extrabold text-gray-800">Pickup Orders</h2>
                <div className="flex gap-2">
                    <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search order # / customer…" className={inputCls + " !w-64"} />
                    <Btn onClick={() => window.open("/api/admin/orders?type=pickup&export=csv", "_blank")} className="bg-white border">⬇ Export</Btn>
                    <Btn onClick={() => nav("create")} className="bg-red-600 text-white hover:bg-red-700">＋ New Pickup Order</Btn>
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border overflow-x-auto">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="text-left text-gray-400 border-b">
                            <th className="p-3 font-semibold">Order #</th>
                            <th className="p-3 font-semibold">Customer</th>
                            <th className="p-3 font-semibold">Phone</th>
                            <th className="p-3 font-semibold">Total</th>
                            <th className="p-3 font-semibold">Status</th>
                            <th className="p-3 font-semibold">Placed</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.data.map((o) => (
                            <tr key={o.id} className="border-b last:border-0 hover:bg-gray-50">
                                <td className="p-3 font-semibold">{o.order_number}</td>
                                <td className="p-3">{o.customer_name}</td>
                                <td className="p-3">{o.customer_phone ?? "—"}</td>
                                <td className="p-3 font-bold">Rs. {Number(o.total).toLocaleString()}</td>
                                <td className="p-3"><StatusSelect order={o} onChanged={load} /></td>
                                <td className="p-3 text-gray-400 text-xs">{new Date(o.created_at).toLocaleString()}</td>
                            </tr>
                        ))}
                        {data.data.length === 0 && <tr><td colSpan={6} className="p-10 text-center text-gray-300">No pickup orders yet</td></tr>}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

/* ---------------- pickup order create (website-style menu) ---------------- */
export function PickupCreate() {
    const [home, setHome] = useState(null);
    const [q, setQ] = useState("");
    const [cart, setCart] = useState([]);
    const [modal, setModal] = useState(null);
    const [customer, setCustomer] = useState({ name: "", phone: "" });
    const [done, setDone] = useState(null);
    const nav = useNavigate();

    useEffect(() => { api.get("/home").then((r) => setHome(r.data)); }, []);

    const items = useMemo(() => {
        if (!home) return [];
        const prods = home.categories.flatMap((c) => c.products.map((p) => ({
            ...p, _kind: "product", _key: `p${p.id}`,
            modifiers: [
                ...(p.options?.length ? [{ id: -1, _key: `p${p.id}-opt`, name: p.options_title || "Options", type: "single", required: true, options: p.options }] : []),
                ...(p.extras?.length ? [{ id: -2, _key: `p${p.id}-ext`, name: p.extras_title || "Extras", type: "multiple", required: false, options: p.extras }] : []),
            ],
            _disabled: ["website", "unavailable"].includes(p.availability),
        })));
        const deals = home.deals.map((d) => ({
            ...d, _kind: "deal", _key: `d${d.id}`,
            modifiers: [
                ...(d.options?.length ? [{ id: -1, _key: `d${d.id}-opt`, name: d.options_title || "Options", type: "single", required: true, options: d.options }] : []),
                ...(d.extras?.length ? [{ id: -2, _key: `d${d.id}-ext`, name: d.extras_title || "Extras", type: "multiple", required: false, options: d.extras }] : []),
            ],
            _disabled: false,
        }));
        return [...deals, ...prods].filter((i) =>
            i.name.toLowerCase().includes(q.toLowerCase()));
    }, [home, q]);

    if (!home) return <Spinner />;
    if (done) return (
        <div className="max-w-md mx-auto text-center py-16">
            <p className="text-6xl mb-4">🎉</p>
            <h2 className="text-2xl font-extrabold">Order {done.order_number} placed!</h2>
            <Btn onClick={() => nav("/orders/pickup")} className="mt-6 bg-red-600 text-white">Back to Pickup Orders</Btn>
        </div>
    );

    const add = (item) => {
        if (item.modifiers.length) setModal(item);
        else setCart((c) => upsert(c, { key: item._key, name: item.name, product_id: item._kind === "product" ? item.id : null, deal_id: item._kind === "deal" ? item.id : null, unit_price: Number(item.price), qty: 1, modifiers: [] }));
    };
    const upsert = (cart, line) => {
        const ex = cart.find((l) => l.key === line.key);
        return ex ? cart.map((l) => (l.key === line.key ? { ...l, qty: l.qty + 1 } : l)) : [...cart, line];
    };
    const total = cart.reduce((s, l) => s + l.unit_price * l.qty, 0);

    const place = async () => {
        if (!customer.name) return alert("Enter customer name");
        if (!cart.length) return alert("Cart is empty");
        const r = await api.post("/admin/orders", {
            customer_name: customer.name, customer_phone: customer.phone,
            items: cart.map(({ key, ...l }) => l),
        });
        setDone(r.data);
    };

    return (
        <div>
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <h2 className="text-xl font-extrabold text-gray-800">New Pickup Order</h2>
                <div className="flex items-center gap-2">
                    <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 Search menu…" className={inputCls + " !w-64"} />
                    <Btn onClick={() => nav("/orders/pickup")} className="bg-white border">← Back</Btn>
                </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2 mb-6">
                {items.map((item) => <MiniCard key={item._key} item={item} onAdd={add} />)}
            </div>

            <div className="bg-white rounded-2xl border shadow-sm p-5 max-w-xl">
                <h3 className="font-bold mb-3">🛒 Cart ({cart.reduce((s, l) => s + l.qty, 0)})</h3>
                {cart.length === 0 && <p className="text-sm text-gray-300">Tap items above to add</p>}
                {cart.map((l) => (
                    <div key={l.key} className="flex items-center justify-between text-sm py-1.5 border-b last:border-0">
                        <span>{l.name}
                            {l.modifiers.length > 0 && <span className="block text-xs text-gray-400">+ {l.modifiers.map((m) => m.option.name).join(", ")}</span>}
                        </span>
                        <span className="flex items-center gap-2">
                            <button onClick={() => setCart((c) => c.map((x) => x.key === l.key ? { ...x, qty: Math.max(0, x.qty - 1) } : x).filter((x) => x.qty > 0))} className="w-6 h-6 border rounded-full">−</button>
                            {l.qty}
                            <button onClick={() => setCart((c) => c.map((x) => x.key === l.key ? { ...x, qty: x.qty + 1 } : x))} className="w-6 h-6 border rounded-full">+</button>
                            <b className="w-20 text-right">Rs. {(l.unit_price * l.qty).toLocaleString()}</b>
                        </span>
                    </div>
                ))}
                <div className="flex gap-2 mt-4">
                    <input placeholder="Customer name *" value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} className={inputCls} />
                    <input placeholder="Phone" value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} className={inputCls} />
                </div>
                <Btn onClick={place} disabled={!cart.length}
                    className="mt-4 w-full bg-red-600 text-white justify-center py-3 disabled:opacity-40">
                    Place Pickup Order — Rs. {total.toLocaleString()}
                </Btn>
            </div>

            {modal && (
                <MiniModal item={modal} onClose={() => setModal(null)}
                    onConfirm={(mods, unit) => {
                        setCart((c) => upsert(c, {
                            key: `${modal._key}|${mods.map((m) => m.option.id).sort().join(",")}`,
                            name: modal.name, product_id: modal._kind === "product" ? modal.id : null,
                            deal_id: modal._kind === "deal" ? modal.id : null,
                            unit_price: unit, qty: 1, modifiers: mods,
                        }));
                        setModal(null);
                    }} />
            )}
        </div>
    );
}
