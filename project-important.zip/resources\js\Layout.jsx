import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "./auth";

const NAV = [
    { label: "Dashboard", path: "/", module: "dashboard", exact: true },
    { label: "Website Banner", path: "/banners", module: "banners" },
    { label: "Products", path: "/products", module: "products", children: true },
    { label: "— Products", path: "/products", module: "products", sub: true },
    { label: "— Extras", path: "/extras", module: "extras", sub: true },
    { label: "— Options", path: "/options", module: "options", sub: true },
    { label: "Categories", path: "/categories", module: "categories" },
    { label: "Deals", path: "/deals", module: "deals" },
    { label: "Sales", path: "/orders/website", module: "orders", children: true },
    { label: "— Pickup Orders", path: "/orders/pickup", module: "orders", sub: true },
    { label: "— Website Orders", path: "/orders/website", module: "orders", sub: true },
    { label: "Inventory", path: "/stock-items", module: "stock-items", children: true },
    { label: "— Stock Items", path: "/stock-items", module: "stock-items", sub: true },
    { label: "— Stock Use Voucher", path: "/stock-use", module: "stock-use", sub: true },
    { label: "Users", path: "/users", module: "users" },
    { label: "Roles", path: "/roles", module: "roles" },
];

export default function Layout() {
    const { user, logout, can } = useAuth();

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* sidebar */}
            <aside className="w-64 bg-[#1F2430] text-gray-300 flex flex-col fixed inset-y-0">
                <div className="h-16 flex items-center px-5 text-xl font-extrabold text-white">
                    🍽️ <span className="ml-2 text-red-500">RMS</span>
                </div>
                <nav className="flex-1 overflow-y-auto px-3 pb-6 space-y-0.5">
                    {NAV.filter((n) => !n.children && can(n.module)).map((n) =>
                        n.sub ? (
                            <NavLink key={n.label} to={n.path}
                                className={({ isActive }) =>
                                    "block pl-8 pr-4 py-2 text-sm rounded-lg transition " +
                                    (isActive ? "bg-red-600 text-white font-semibold" : "hover:bg-white/10")}>
                                {n.label.slice(2)}
                            </NavLink>
                        ) : (
                            <NavLink key={n.label} to={n.path} end={n.exact}
                                className={({ isActive }) =>
                                    "block px-4 py-2 text-sm rounded-lg transition " +
                                    (isActive ? "bg-red-600 text-white font-semibold" : "hover:bg-white/10")}>
                                {n.label}
                            </NavLink>
                        )
                    )}
                </nav>
            </aside>

            {/* main */}
            <div className="flex-1 ml-64">
                {/* header */}
                <header className="h-16 bg-white border-b flex items-center justify-between px-6 sticky top-0 z-30">
                    <h1 className="font-bold text-gray-700">Restaurant Management System</h1>
                    <div className="flex items-center gap-4">
                        <div className="text-right">
                            <p className="text-sm font-bold text-gray-800 leading-tight">{user?.name}</p>
                            <p className="text-xs text-gray-400">{user?.role?.name}</p>
                        </div>
                        <button onClick={logout}
                            className="bg-red-600 hover:bg-red-700 text-white text-sm font-semibold px-4 py-2 rounded-xl transition">
                            Logout
                        </button>
                    </div>
                </header>
                <main className="p-6">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
