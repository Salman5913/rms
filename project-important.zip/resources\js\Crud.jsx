import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import api from "./api";
import { Btn, Field, ImageUpload, MultiSelect, Spinner, inputCls } from "./ui";

/* ================= generic listing page ================= */
export function CrudPage({ title, endpoint, columns, searchPlaceholder = "Search…", canCreate = true, canImport = true, canExport = true, extraActions }) {
    const [data, setData] = useState(null);
    const [page, setPage] = useState(1);
    const [search, setSearch] = useState("");
    const [selected, setSelected] = useState([]);
    const [importOpen, setImportOpen] = useState(false);
    const nav = useNavigate();

    const load = (p = page, s = search) =>
        api.get(`/${endpoint}`, { params: { page: p, search: s } }).then((r) => setData(r.data));

    useEffect(() => { load(1); }, [endpoint]); // eslint-disable-line
    useEffect(() => { const t = setTimeout(() => load(1, search), 300); return () => clearTimeout(t); }, [search]); // eslint-disable-line

    const toggleAll = (e) => setSelected(e.target.checked ? data.data.map((r) => r.id) : []);
    const toggleOne = (id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

    const bulkDelete = async () => {
        if (!selected.length || !confirm(`Delete ${selected.length} record(s)?`)) return;
        await api.post(`/${endpoint}-bulk-delete`, { ids: selected });
        setSelected([]); load(1);
    };

    const destroy = async (id) => {
        if (!confirm("Delete this record?")) return;
        await api.delete(`/${endpoint}/${id}`); load();
    };

    const doExport = () => { window.open(`/api/${endpoint}?export=csv`, "_blank"); };

    const rows = data?.data ?? [];
    const allChecked = rows.length > 0 && rows.every((r) => selected.includes(r.id));

    return (
        <div>
            <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
                <h2 className="text-xl font-extrabold text-gray-800">{title}</h2>
                <div className="flex gap-2">
                    <input value={search} onChange={(e) => setSearch(e.target.value)}
                        placeholder={searchPlaceholder} className={inputCls + " !w-64"} />
                    {canImport && <Btn onClick={() => setImportOpen(true)} className="bg-white border">⬆ Import</Btn>}
                    {canExport && <Btn onClick={doExport} className="bg-white border">⬇ Export</Btn>}
                    <Btn onClick={bulkDelete} disabled={!selected.length}
                        className="bg-red-50 text-red-600 border border-red-200 disabled:opacity-40">🗑 Trash ({selected.length})</Btn>
                    {canCreate && <Btn onClick={() => nav("create")} className="bg-red-600 text-white hover:bg-red-700">＋ Create</Btn>}
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border overflow-x-auto">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="text-left text-gray-400 border-b">
                            <th className="p-3 w-10"><input type="checkbox" checked={allChecked} onChange={toggleAll} className="accent-red-600" /></th>
                            {columns.map((c) => <th key={c.key} className="p-3 font-semibold">{c.label}</th>)}
                            <th className="p-3 w-28 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((row) => (
                            <tr key={row.id} className={"border-b last:border-0 hover:bg-gray-50 " + (selected.includes(row.id) ? "bg-red-50/40" : "")}>
                                <td className="p-3"><input type="checkbox" checked={selected.includes(row.id)} onChange={() => toggleOne(row.id)} className="accent-red-600" /></td>
                                {columns.map((c) => (
                                    <td key={c.key} className="p-3">
                                        {c.render ? c.render(row) : String(row[c.key] ?? "—")}
                                    </td>
                                ))}
                                <td className="p-3">
                                    <div className="flex justify-end gap-1.5">
                                        <Link to={`${row.id}`} title="View" className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center">👁</Link>
                                        <Link to={`${row.id}/edit`} title="Edit" className="w-8 h-8 rounded-lg bg-blue-50 hover:bg-blue-100 flex items-center justify-center">✏️</Link>
                                        <button onClick={() => destroy(row.id)} title="Delete" className="w-8 h-8 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center">🗑</button>
                                        {extraActions?.(row)}
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {rows.length === 0 && <tr><td colSpan={columns.length + 2} className="p-10 text-center text-gray-300">No records found</td></tr>}
                    </tbody>
                </table>
            </div>

            {data && data.last_page > 1 && (
                <div className="flex gap-2 mt-4 justify-center">
                    {Array.from({ length: data.last_page }, (_, i) => i + 1).map((p) => (
                        <button key={p} onClick={() => { setPage(p); load(p); }}
                            className={"w-9 h-9 rounded-lg text-sm font-semibold " + (p === data.current_page ? "bg-red-600 text-white" : "bg-white border hover:bg-gray-50")}>
                            {p}
                        </button>
                    ))}
                </div>
            )}

            {importOpen && <ImportModal endpoint={endpoint} columns={columns} onClose={() => setImportOpen(false)}
                onDone={() => { setImportOpen(false); load(1); }} />}
        </div>
    );
}

/* ================= generic form page (create / edit / view) ================= */
export function CrudForm({ title, endpoint, fields, backTo }) {
    const { id } = useParams();
    const nav = useNavigate();
    const isView = location.pathname.endsWith(`/${id}`) && !location.pathname.includes("edit");
    const [values, setValues] = useState(null);
    const [errors, setErrors] = useState({});
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (id) {
            api.get(`/${endpoint}/${id}`).then((r) => {
                const d = r.data;
                const init = {};
                fields.forEach((f) => {
                    init[f.name] = f.many
                        ? (d[f.name]?.map((x) => x.id) ?? f.default ?? [])
                        : (d[f.name] ?? f.default ?? (f.type === "checkbox" ? false : ""));
                });
                setValues(init);
            });
        } else {
            const init = {};
            fields.forEach((f) => (init[f.name] = f.default ?? (f.type === "checkbox" ? false : f.type === "multiselect" ? [] : "")));
            setValues(init);
        }
    }, [id, endpoint]); // eslint-disable-line

    if (!values) return <Spinner />;

    const set = (name, v) => setValues((s) => ({ ...s, [name]: v }));

    const validate = () => {
        const e = {};
        fields.forEach((f) => {
            if (f.required && (values[f.name] === "" || values[f.name] == null ||
                (Array.isArray(values[f.name]) && values[f.name].length === 0))) {
                e[f.name] = `${f.label} is required`;
            }
        });
        setErrors(e);
        return Object.keys(e).length === 0;
    };

    const save = async () => {
        if (!validate()) return;
        setSaving(true);
        try {
            const payload = { ...values };
            if (id) await api.post(`/${endpoint}/${id}`, payload);
            else await api.post(`/${endpoint}`, payload);
            nav(backTo);
        } catch (err) {
            alert(err.response?.data?.message ?? "Validation failed — check required fields");
        } finally { setSaving(false); }
    };

    return (
        <div className="max-w-2xl">
            <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-extrabold text-gray-800">{id ? (isView ? "View" : "Edit") : "Create"} {title}</h2>
                <Btn onClick={() => nav(backTo)} className="bg-white border">← Back</Btn>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border p-6 space-y-5">
                {fields.map((f) => (
                    <Field key={f.name} label={f.label} required={f.required}>
                        {f.render ? (
                            f.render({ value: values[f.name], onChange: (v) => set(f.name, v), disabled: isView })
                        ) : f.type === "textarea" ? (
                            <textarea rows={3} value={values[f.name]} disabled={isView}
                                onChange={(e) => set(f.name, e.target.value)} className={inputCls} />
                        ) : f.type === "select" ? (
                            <select value={values[f.name]} disabled={isView}
                                onChange={(e) => set(f.name, e.target.value)} className={inputCls}>
                                <option value="">— select —</option>
                                {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        ) : f.type === "checkbox" ? (
                            <input type="checkbox" checked={!!values[f.name]} disabled={isView}
                                onChange={(e) => set(f.name, e.target.checked)} className="w-4 h-4 accent-red-600" />
                        ) : f.type === "image" ? (
                            !isView && <ImageUpload value={values[f.name]} onChange={(v) => set(f.name, v)} />
                        ) : f.type === "multiselect" ? (
                            !isView ? <MultiSelect endpoint={f.endpoint} value={values[f.name]}
                                onChange={(v) => set(f.name, v)} placeholder={f.label} />
                                : <p className="text-sm text-gray-500">{(values[f.name] ?? []).join(", ")}</p>
                        ) : (
                            <input type={f.type ?? "text"} value={values[f.name]} disabled={isView}
                                onChange={(e) => set(f.name, f.type === "number" ? e.target.value : e.target.value)}
                                className={inputCls} />
                        )}
                        {errors[f.name] && <p className="text-xs text-red-500 mt-1">{errors[f.name]}</p>}
                    </Field>
                ))}

                {!isView && (
                    <div className="pt-2">
                        <Btn onClick={save} disabled={saving}
                            className="bg-red-600 text-white hover:bg-red-700 disabled:opacity-50">
                            {saving ? "Saving…" : "💾 Save"}
                        </Btn>
                    </div>
                )}
            </div>
        </div>
    );
}

/* ================= import modal (sample download + paste/CSV rows) ================= */
function ImportModal({ endpoint, columns, onClose, onDone }) {
    const [rows, setRows] = useState("");
    const [busy, setBusy] = useState(false);

    const downloadSample = () => {
        const header = columns.map((c) => c.key).join(",");
        const example = columns.map((c) => c.sample ?? "").join(",");
        const blob = new Blob([`${header}\n${example}`], { type: "text/csv" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `${endpoint}-sample.csv`;
        a.click();
    };

    const runImport = async () => {
        const lines = rows.trim().split("\n").filter(Boolean);
        if (lines.length < 2) return alert("Paste CSV rows (header + data) first");
        const header = lines[0].split(",").map((h) => h.trim());
        const parsed = lines.slice(1).map((line) => {
            const cells = line.split(",");
            const obj = {};
            header.forEach((h, i) => (obj[h] = cells[i]?.trim() ?? ""));
            return obj;
        });
        setBusy(true);
        try {
            const r = await api.post(`/import/${endpoint}`, { rows: parsed });
            alert(`Imported ${r.data.imported} rows`);
            onDone();
        } catch (err) {
            alert(err.response?.data?.message ?? "Import failed — check column names match the sample");
        } finally { setBusy(false); }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40" onClick={onClose} />
            <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-lg p-6">
                <h3 className="font-bold text-lg mb-1">Import {endpoint}</h3>
                <button onClick={downloadSample} className="text-sm text-red-600 font-semibold underline mb-3">
                    ⬇ Download sample file (columns match the database)
                </button>
                <textarea rows={8} value={rows} onChange={(e) => setRows(e.target.value)}
                    placeholder={"Paste CSV content here…\n" + columns.map((c) => c.key).join(",")}
                    className={inputCls + " font-mono text-xs"} />
                <div className="flex justify-end gap-2 mt-4">
                    <Btn onClick={onClose} className="bg-gray-100">Cancel</Btn>
                    <Btn onClick={runImport} disabled={busy} className="bg-red-600 text-white disabled:opacity-50">
                        {busy ? "Importing…" : "Import"}
                    </Btn>
                </div>
            </div>
        </div>
    );
}
