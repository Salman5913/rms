<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    private const CSV_MAP = ['RECEIVED' => 'PLACED', 'READY' => 'PREPARING',
        'OUT_FOR_DELIVERY' => 'ON_THE_WAY', 'DELIVERED' => 'DELIVERED'];

    public function index(Request $request)
    {
        $q = Order::with('items')->where('type', $request->query('type', 'website'));

        if ($s = $request->query('search')) {
            $q->where(fn ($qq) => $qq->where('order_number', 'like', "%{$s}%")
                ->orWhere('customer_name', 'like', "%{$s}%")
                ->orWhere('customer_phone', 'like', "%{$s}%"));
        }

        if ($request->query('export') === 'csv') {
            $rows = $q->orderByDesc('id')->get();
            return response()->streamDownload(function () use ($rows) {
                $out = fopen('php://output', 'w');
                fputcsv($out, ['order_number', 'customer_name', 'customer_phone', 'status', 'total', 'created_at']);
                foreach ($rows as $r) {
                    fputcsv($out, [$r->order_number, $r->customer_name, $r->customer_phone,
                        self::CSV_MAP[$r->status] ?? $r->status, $r->total, $r->created_at]);
                }
                fclose($out);
            }, 'orders.csv', ['Content-Type' => 'text/csv']);
        }

        return response()->json($q->orderByDesc('id')->paginate(15));
    }

    public function show($id)
    {
        return response()->json(Order::with('items')->findOrFail($id));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'customer_name'  => 'required|string',
            'customer_phone' => 'nullable|string',
            'notes'          => 'nullable|string',
            'items'          => 'required|array|min:1',
            'items.*.product_id' => 'nullable|integer',
            'items.*.deal_id'    => 'nullable|integer',
            'items.*.name'       => 'required|string',
            'items.*.unit_price' => 'required|numeric',
            'items.*.qty'        => 'required|integer|min:1',
            'items.*.modifiers'  => 'nullable|array',
        ]);

        $order = DB::transaction(function () use ($data) {
            $total = collect($data['items'])->sum(fn ($i) => $i['unit_price'] * $i['qty']);
            $order = Order::create([
                'order_number'   => 'PKP-'.now()->format('ymd').'-'.strtoupper(bin2hex(random_bytes(2))),
                'type'           => 'pickup',
                'customer_name'  => $data['customer_name'],
                'customer_phone' => $data['customer_phone'] ?? null,
                'status'         => 'RECEIVED',
                'total'          => $total,
            ]);
            foreach ($data['items'] as $i) {
                $order->items()->create($i + ['product_id' => $i['product_id'] ?? null, 'deal_id' => $i['deal_id'] ?? null]);
            }
            return $order;
        });

        return response()->json($order->load('items'), 201);
    }

    public function updateStatus(Request $request, $id)
    {
        $data = $request->validate(['status' => 'required|in:RECEIVED,READY,OUT_FOR_DELIVERY,DELIVERED']);
        $order = Order::findOrFail($id);
        $order->update(['status' => $data['status']]);
        return response()->json($order);
    }

    public function markViewed($id)
    {
        $order = Order::findOrFail($id);
        $order->update(['is_viewed' => 1]);
        return response()->json(['ok' => true]);
    }

    public function destroy($id)
    {
        Order::findOrFail($id)->delete();
        return response()->json(['ok' => true]);
    }

    public function bulkDelete(Request $request)
    {
        $ids = $request->validate(['ids' => 'required|array'])['ids'];
        Order::whereIn('id', $ids)->delete();
        return response()->json(['ok' => true]);
    }
}
