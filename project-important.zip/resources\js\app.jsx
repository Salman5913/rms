import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Navigate, Outlet, Route, Routes } from "react-router-dom";
import { AuthProvider, useAuth } from "./auth";
import Layout from "./Layout";
import { Spinner } from "./ui";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Banners from "./pages/Banners";
import Products from "./pages/Products";
import Extras from "./pages/Extras";
import Options from "./pages/Options";
import Categories from "./pages/Categories";
import Deals from "./pages/Deals";
import StockItems from "./pages/StockItems";
import StockUse from "./pages/StockUse";
import Users from "./pages/Users";
import Roles from "./pages/Roles";
import WebsiteOrders, { WebsiteOrderView } from "./pages/WebsiteOrders";
import PickupOrders, { PickupCreate } from "./pages/PickupOrders";
import "./index.css";

function Guard() {
    const { user, loading } = useAuth();
    if (loading) return <Spinner />;
    if (!user) return <Navigate to="/login" />;
    return <Outlet />;
}

function App() {
    return (
        <Routes>
            <Route path="/login" element={<Login />} />
            <Route element={<Guard />}>
                <Route element={<Layout />}>
                    <Route index element={<Dashboard />} />
                    <Route path="banners" element={<Banners />} />
                    <Route path="products/*" element={<Products />} />
                    <Route path="extras/*" element={<Extras />} />
                    <Route path="options/*" element={<Options />} />
                    <Route path="categories/*" element={<Categories />} />
                    <Route path="deals/*" element={<Deals />} />
                    <Route path="stock-items/*" element={<StockItems />} />
                    <Route path="stock-use" element={<StockUse />} />
                    <Route path="users/*" element={<Users />} />
                    <Route path="roles/*" element={<Roles />} />
                    <Route path="orders/website" element={<WebsiteOrders />} />
                    <Route path="orders/website/:id" element={<WebsiteOrderView />} />
                    <Route path="orders/pickup" element={<PickupOrders />} />
                    <Route path="orders/pickup/create" element={<PickupCreate />} />
                </Route>
            </Route>
        </Routes>
    );
}

createRoot(document.getElementById("app")).render(
    <BrowserRouter>
        <AuthProvider>
            <App />
        </AuthProvider>
    </BrowserRouter>
);
