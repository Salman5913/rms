import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import api from "../api";
import { Btn, Spinner, inputCls } from "../ui";

const STATUSES = ["RECEIVED", "READY", "OUT_FOR_DELIVERY", "DELIVERED"];
const STATUS_LABEL = { RECEIVED: "Received", READY: "Ready", OUT_FOR_DELIVERY: "Out for Delivery", DELIVERED: "Delivered" };

export function StatusSelect({ order, onChanged }) {
    const [status, setStatus] = useState(order.status);
    return (
        <select value={status} onChange={async (e) => {
            setStatus(e.target.value);
            await api.post(`/admin/orders/${order.id}/status`, { status: e.target.value });
            onChanged?.();
        }} className="border rounded-lg px-2 py-1.5 text-xs font-semibold bg-white">
            {STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
    );
}

export default function WebsiteOrders() {
    const [data, setData] = useState(null);
    const [search, setSearch] = useState("");

    const load = (s = search) =>
        api.get("/admin/orders", { params: { type: "website", search: s } }).then((r) => setData(r.data));

    useEffect(() => { load(); }, []); // eslint-disable-line
    useEffect(() => { const t = setTimeout(() => load(search), 300); return () => clearTimeout(t); }, [search]); // eslint-disable-line

    if (!data) return <Spinner />;
    const nav = useNavigate();

    return (
        <div>
            <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
                <h2 className="text-xl font-extrabold text-gray-800">Website Orders</h2>
                <div className="flex gap-2">
                    <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search order # / customer…" className={inputCls + " !w-64"} />
                    <Btn onClick={() => window.open("/api/admin/orders?type=website&export=csv", "_blank")} className="bg-white border">⬇ Export</Btn>
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border overflow-x-auto">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="text-left text-gray-400 border-b">
                            <th className="p-3 font-semibold">Order #</th>
                            <th className="p-3 font-semibold">Customer</th>
                            <th className="p-3 font-semibold">Phone</th>
                            <th className="p-3 font-semibold">Items</th>
                            <th className="p-3 font-semibold">Total</th>
                            <th className="p-3 font-semibold">Status</th>
                            <th className="p-3 font-semibold">Placed</th>
                            <th className="p-3 w-20 text-right">View</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.data.map((o) => (
                            <tr key={o.id} onClick={() => nav(`${o.id}`)}
                                className={"border-b last:border-0 cursor-pointer " + (!o.is_viewed ? "bg-yellow-50 hover:bg-yellow-100" : "hover:bg-gray-50")}>
                                <td className="p-3 font-semibold">{o.order_number}{!o.is_viewed && <span className="ml-2 text-[10px] bg-yellow-400 text-yellow-900 font-bold px-1.5 py-0.5 rounded-full">NEW</span>}</td>
                                <td className="p-3">{o.customer_name}</td>
                                <td className="p-3">{o.customer_phone}</td>
                                <td className="p-3">{o.items.reduce((s, i) => s + i.qty, 0)}</td>
                                <td className="p-3 font-bold">Rs. {Number(o.total).toLocaleString()}</td>
                                <td className="p-3" onClick={(e) => e.stopPropagation()}>
                                    <StatusSelect order={o} onChanged={load} />
                                </td>
                                <td className="p-3 text-gray-400 text-xs">{new Date(o.created_at).toLocaleString()}</td>
                                <td className="p-3 text-right"><Link to={`${o.id}`} className="inline-block w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-center leading-8">👁</Link></td>
                            </tr>
                        ))}
                        {data.data.length === 0 && <tr><td colSpan={8} className="p-10 text-center text-gray-300">No orders yet</td></tr>}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export function WebsiteOrderView() {
    const { id } = useParams();
    const [order, setOrder] = useState(null);
    const nav = useNavigate();

    useEffect(() => {
        api.get(`/admin/orders/${id}`).then((r) => {
            setOrder(r.data);
            if (!r.data.is_viewed) api.post(`/admin/orders/${id}/viewed`);
        });
    }, [id]);

    if (!order) return <Spinner />;

    return (
        <div className="max-w-2xl">
            <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-extrabold text-gray-800">Order {order.order_number}</h2>
                <div className="flex items-center gap-2">
                    <StatusSelect order={order} onChanged={() => api.get(`/admin/orders/${id}`).then((r) => setOrder(r.data))} />
                    <Btn onClick={() => nav("/orders/website")} className="bg-white border">← Back</Btn>
                </div>
            </div>

            <div className="bg-white rounded-2xl border shadow-sm p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                    <p><span className="text-gray-400">Customer:</span> <b>{order.customer_name}</b></p>
                    <p><span className="text-gray-400">Phone:</span> <b>{order.customer_phone}</b></p>
                    <p className="col-span-2"><span className="text-gray-400">Address:</span> {order.address}</p>
                    {order.notes && <p className="col-span-2"><span className="text-gray-400">Notes:</span> {order.notes}</p>}
                </div>
                <div className="border-t pt-3 space-y-2">
                    {order.items.map((i) => (
                        <div key={i.id} className="flex justify-between text-sm">
                            <span>{i.name} × {i.qty}
                                {i.modifiers?.length > 0 && (
                                    <span className="block text-xs text-gray-400">{i.modifiers.map((m) => m.option?.name ?? m.name).join(", ")}</span>
                                )}
                            </span>
                            <span className="font-semibold">Rs. {(i.unit_price * i.qty).toLocaleString()}</span>
                        </div>
                    ))}
                </div>
                <div className="border-t pt-3 flex justify-between font-extrabold">
                    <span>Total</span><span className="text-red-600">Rs. {Number(order.total).toLocaleString()}</span>
                </div>
            </div>
        </div>
    );
}
